import { Component } from '@angular/core';

@Component({
  selector: 'app-shift-entry-list',
  imports: [],
  templateUrl: './shift-entry-list.html',
  styleUrl: './shift-entry-list.css'
})
export class ShiftEntryList {

}
