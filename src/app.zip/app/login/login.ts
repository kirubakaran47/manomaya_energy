import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
@Component({
  selector: 'app-login',
  standalone: true,
  imports: [FormsModule,CommonModule],
  templateUrl: './login.html',
  styleUrl: './login.css'
})
export class Login {
  email = '';
  password = '';
  errorMessage = '';
  templateAuthView = true; 

  constructor(private router: Router) {}
ngOnInit(): void {
  if (localStorage.getItem('access_token')) {
    this.router.navigate(['/dashboard'], { replaceUrl: true });
  }
}

   onSubmit() {
    if (this.email === 'demo@example.com' && this.password === 'password123') {
      localStorage.setItem('access_token', 'demo-token-123');
      this.router.navigate(['/dashboard'], { replaceUrl: true });
    } else {
      this.errorMessage = 'Invalid email or password';
    }
  }
}
