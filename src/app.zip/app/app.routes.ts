
import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { Dashboard } from './dashboard/dashboard';
import { ShiftEntry } from './shift-entry/shift-entry';
import { ShiftEntryList } from './shift-entry-list/shift-entry-list';
import { Login } from './login/login';
export const routes: Routes = [
  { path: 'dashboard', component: Dashboard },
  { path: 'shiftEntry', component: ShiftEntry },
  { path: 'shiftEntryList', component: ShiftEntryList },
  { path: 'login', component: Login },
  { path: '', redirectTo: 'login', pathMatch: 'full' }, 
  { path: '**', redirectTo: 'login' }
];


@NgModule({
  imports: [RouterModule.forRoot(routes,{ useHash: true })],
  exports: [RouterModule]
})
export class AppRoutingModule { } 