import { Component } from '@angular/core';
import { Router } from '@angular/router';
@Component({
  selector: 'app-navbar',
  imports: [],
  standalone: true,
  templateUrl: './navbar.html',
  styleUrl: './navbar.css'
})
export class Navbar {
 constructor(private router: Router) {}
 logout() {
    localStorage.removeItem('access_token'); 
    this.router.navigate(['/login']); //
  }
   toggleMobileMenu(): void {
    document.body.classList.toggle('mobile-menu-open');
  }
}
