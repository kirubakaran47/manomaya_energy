import { Component,OnInit } from '@angular/core';
import { RouterModule } from '@angular/router';
import { Router, NavigationEnd } from '@angular/router';
import { CommonModule } from '@angular/common';
import { ChangeDetectorRef } from '@angular/core';
import { filter } from 'rxjs/operators';
@Component({
  selector: 'app-sidebar',
  standalone: true,
  imports: [RouterModule,CommonModule],
  templateUrl: './sidebar.html',
  styleUrl: './sidebar.css'
})
export class Sidebar implements OnInit{
  activeMenu: string = '';
constructor(private router: Router, private cd: ChangeDetectorRef) {}


 ngOnInit(): void {
    // Set active menu on load
    this.setActiveMenu(this.router.url);

    // Update on every route change
    this.router.events.subscribe(event => {
      if (event instanceof NavigationEnd) {
        this.setActiveMenu(event.urlAfterRedirects);
      }
    });
  }
setActiveMenu(url: string): void {
    if (url.startsWith('/shiftEntry') || url.startsWith('/manageShiftEntry')) {
      this.activeMenu = 'shiftEntry';
    } else if (url.startsWith('/employee')) {
      this.activeMenu = 'employee';
    } else if (url.startsWith('/fuel')) {
      this.activeMenu = 'fuel';
    } else {
      this.activeMenu = ''; 
    }
  }

  toggleMenu(menu: string): void {
    this.activeMenu = this.activeMenu === menu ? '' : menu;
  }
   toggleMobileMenu(): void {
    document.body.classList.toggle('mobile-menu-open');
  }
}
