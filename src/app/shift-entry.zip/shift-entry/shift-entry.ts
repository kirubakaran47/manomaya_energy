import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { NgSelectModule } from '@ng-select/ng-select';
import { Server } from '../server';
import iziToast from 'izitoast';

@Component({
  selector: 'app-shift-entry',
  standalone: true,
  imports: [NgSelectModule, CommonModule, FormsModule],
  templateUrl: './shift-entry.html',
  styleUrls: ['./shift-entry.css']
})

export class ShiftEntry {
  constructor(private serverService: Server) { }

  pumpSelection: { [key: string]: boolean } = {
    // 'pump1-nozzle1-petrol': false,
    // 'pump1-nozzle2-diesel': false,
    // 'pump2-nozzle1-petrol': false,
    // 'pump2-nozzle2-diesel': false
  };

  operators: any[] = [];
  keyword: string = '';
  isPumpSelectedA: boolean = false;
  isPumpSelectedB: boolean = false;
  errorMessages: string[] = [];
  selectedPump: null | undefined;
shiftA = {
  entries: [{
    shiftDate: '',
    pump: '',
    shift: '',
    fuelType: '',
    opening: 0,
    closing: 0,
    sales: 0,
    operatorName: '',
    price: 0,
    total: 0,
    shiftcoins: 0,
    shiftgpay: 0,
    shiftphonepe: 0,
    shiftswiping: 0,
    shiftcash: 0,
    shiftcredit: 0,
    shifttotal: 0,
    shiftreceipt: 0,
    shiftgrandtotal: 0,
    shiftfueltotal: 0,
    shifttest: 0,
    shiftoilsales: 0,
    shiftdiscount: 0,
    shiftextrafuel: 0,
    shiftgtotal: 0,
    shiftdifference: 0,
    errors: {} as Record<string, string> 
  }],
};


  shiftB = {
    entries: [{ shiftDate: '', pump: '', shift: '', fuelType: '', opening: 0, closing: 0, sales: 0, operatorName: '', price: '', total: '' }],
  };


  ngOnInit() {
    const today = new Date();
    const ddMMyyyy = today.toISOString().split('T')[0];
    this.shiftA.entries[0].shiftDate = ddMMyyyy;
    this.shiftB.entries[0].shiftDate = ddMMyyyy;
    this.getOperator();
  }

  getOperator(keyword: string = ''): void {
    const user_id = localStorage.getItem('user_id');
    const requestData = {
      moduleType: 'shift_entry',
      api_type: 'api',
      api_url: 'get_operators',
      user_id: user_id,
      keyword: keyword,
    };
    this.serverService.sendServer(requestData).subscribe({
      next: (response: any) => {
        console.log('Login Response:', response);

        // Check if the response contains the operator list and assign it to operators
        if (response && response.operator_list) {
          this.operators = response.operator_list.map((operator: any) => ({
            id: operator.user_id,
            name: operator.full_name
          }));
        }
      },
      error: (err) => {
        console.error('Error fetching operators:', err);
      }
    });
  }
  onSearchChange(event: any): void {
    this.keyword = event.term;
    this.getOperator(this.keyword);
  }

// Helper: safe number
private n(v: any): number { return typeof v === 'number' ? v : parseFloat(v) || 0; }

updateSalesA(index: number) {
  const entry = this.shiftA.entries[index];
  entry.sales = Math.max(0, this.n(entry.closing) - this.n(entry.opening));
  entry.total = +( (this.n(entry.sales) * this.n(entry.price)) ).toFixed(2);
  this.calculateTotalsA();
}

calculateTotalsA() {
  // Ensure each row total = sales * price (in case price changed)
  this.shiftA.entries.forEach(e => {
    e.total = +((this.n(e.sales) * this.n(e.price))).toFixed(2);
  });

  // Step 1: shiftfueltotal = sum of row totals
  const e0 = this.shiftA.entries[0];
  e0.shiftfueltotal = +(
    this.shiftA.entries.reduce((sum, e) => sum + this.n(e.total), 0)
  ).toFixed(2);

  // Step 2: FIXED SIGNS
  // shiftgtotal = shiftfueltotal - shifttest + shiftoilsales - shiftdiscount - shiftextrafuel
  e0.shiftgtotal = +(
    this.n(e0.shiftfueltotal)
    - this.n(e0.shifttest)
    + this.n(e0.shiftoilsales)
    - this.n(e0.shiftdiscount)
    - this.n(e0.shiftextrafuel)
  ).toFixed(2);

  // Step 3: shifttotal = sum of payment modes
  e0.shifttotal = +(
    this.n(e0.shiftcoins) +
    this.n(e0.shiftgpay) +
    this.n(e0.shiftphonepe) +
    this.n(e0.shiftswiping) +
    this.n(e0.shiftcash) +
    this.n(e0.shiftcredit)
  ).toFixed(2);

  // Step 4: shiftgrandtotal = shifttotal - shiftreceipt
  e0.shiftgrandtotal = +(
    this.n(e0.shifttotal) - this.n(e0.shiftreceipt)
  ).toFixed(2);

  // Step 5: shiftdifference = shiftgrandtotal - shiftgtotal
  e0.shiftdifference = +(
    this.n(e0.shiftgrandtotal) - this.n(e0.shiftgtotal)
  ).toFixed(2);
}


  updateSalesB(index: number) {
    const entry = this.shiftB.entries[index];
    entry.sales = Math.max(0, entry.closing - entry.opening);
    this.updateTotalSalesB();
  }

  updateTotalSalesB() {
    this.shiftB.entries.forEach(entry => entry.sales = Math.max(0, entry.closing - entry.opening));
  }

  updateShiftA() {

    if (this.isValidShiftInline(this.shiftA)) {
      console.log("Shift A Data:", this.shiftA);

      // Success Toast
      iziToast.success({
        message: 'Shift A updated successfully!',
        position: 'topRight',
        timeout: 3000
      });

    } else {

      iziToast.error({
        message: this.errorMessages.join('<br>'),
        position: 'topRight',
        timeout: 5000,
      });
    }
  }

  updateShiftB() {
    this.errorMessages = [];

    if (this.isValidShiftInline(this.shiftB)) {
      console.log("Shift B Data:", this.shiftB);

      // Success Toast
      iziToast.success({
        message: 'Shift B updated successfully!',
        position: 'topRight',
        timeout: 3000
      });

      // Process the shift B data (e.g., save to DB, call API, etc.)
    } else {
      // Error Toast with validation messages
      iziToast.error({
        message: this.errorMessages.join('<br>'),
        position: 'topRight',
        timeout: 5000,
      });
    }
  }

 isValidShiftInline(shift: any): boolean {
  let isValid = true;

  for (const entry of shift.entries) {
    entry.errors = {}; 
    if (entry.opening > entry.closing) {
      entry.errors.opening = 'Opening cannot be greater than Closing.';
      isValid = false;
    }
    if (!entry.operatorName) {
      entry.errors.operatorName = 'Operator Name is required.';
      isValid = false;
    }
    if (!entry.shiftDate) {
      entry.errors.shiftDate = 'Shift Date is required.';
      isValid = false;
    }
    if (!entry.pump) {
      entry.errors.pump = 'Pump Entry is required.';
      isValid = false;
    }
    if (!entry.shift) {
      entry.errors.shift = 'Shift Entry is required.';
      isValid = false;
    }
    if (!entry.fuelType) {
      entry.errors.fuelType = 'Fuel Type Entry is required.';
      isValid = false;
    }
    if (!entry.sales) {
      entry.errors.sales = 'Sales Entry is required.';
      isValid = false;
    }
     if (!entry.price) {
      entry.errors.price = 'Price Entry is required.';
      isValid = false;
    }
     if (!entry.total) {
      entry.errors.total = 'Total Entry is required.';
      isValid = false;
    }
     if (!entry.shiftcoins) {
      entry.errors.shiftcoins = 'Coins Entry is required.';
      isValid = false;
    }
     if (!entry.shiftgpay) {
      entry.errors.shiftgpay = 'Gpay Entry is required.';
      isValid = false;
    }
     if (!entry.shiftphonepe) {
      entry.errors.shiftphonepe = 'Phonepe Entry is required.';
      isValid = false;
    }
     if (!entry.shiftswiping) {
      entry.errors.shiftswiping = 'Swiping Entry is required.';
      isValid = false;
    }
     if (!entry.shiftcash) {
      entry.errors.shiftcash = 'Cash Entry is required.';
      isValid = false;
    }
     if (!entry.shiftcredit) {
      entry.errors.shiftcredit = 'Credit Entry is required.';
      isValid = false;
    }
     if (!entry.shifttotal) {
      entry.errors.shifttotal = 'Total Entry is required.';
      isValid = false;
    }
     if (!entry.shiftreceipt) {
      entry.errors.shiftreceipt = 'Receipt Entry is required.';
      isValid = false;
    }
     if (!entry.shiftgrandtotal) {
      entry.errors.shiftgrandtotal = 'Grand Total Entry is required.';
      isValid = false;
    }
     if (!entry.shiftfueltotal) {
      entry.errors.shiftfueltotal = 'Fuel Total Amount Entry is required.';
      isValid = false;
    }
     if (!entry.shifttest) {
      entry.errors.shifttest = 'Test Entry is required.';
      isValid = false;
    }
     if (!entry.shiftoilsales) {
      entry.errors.shiftoilsales = 'Oil Sales Entry is required.';
      isValid = false;
    }
  }

  return isValid;
}




  onPumpSelectedA(pumpKey: string): void {
    // Reset all selections
    this.pumpSelection = {};

    // Mark selected key as true
    this.pumpSelection[pumpKey] = true;
    this.isPumpSelectedA = true;

    // Parse the selected key
    const [pump, shift, fuel] = pumpKey.split('-');

    // Set values in shiftA.entries[0]
    this.shiftA.entries[0].pump = pump.replace('pump', 'Pump ');
    this.shiftA.entries[0].shift = shift.replace('shift', 'Shift ');
    this.shiftA.entries[0].fuelType = fuel.toUpperCase();

    // Optionally reset other fields
    this.shiftA.entries[0].opening = 0;
    this.shiftA.entries[0].closing = 0;
    this.shiftA.entries[0].sales = 0;
    this.shiftA.entries[0].operatorName = '';
  }
  onPumpSelectedB(pumpKey: string): void {
    // Reset all selections
    this.pumpSelection = {};

    // Mark selected key as true
    this.pumpSelection[pumpKey] = true;
    this.isPumpSelectedB = true;

    // Parse the selected key
    const [pump, shift, fuel] = pumpKey.split('-');

    // Set values in shiftB.entries[0]
    this.shiftB.entries[0].pump = pump.replace('pump', 'Pump ');
    this.shiftB.entries[0].shift = shift.replace('shift', 'Shift ');
    this.shiftB.entries[0].fuelType = fuel.toUpperCase();

    // Optionally reset other fields
    this.shiftB.entries[0].opening = 0;
    this.shiftB.entries[0].closing = 0;
    this.shiftB.entries[0].sales = 0;
    this.shiftB.entries[0].operatorName = '';
  }

  onShiftTabChange(shift: 'A' | 'B'): void {
    this.selectedPump = null;
    this.isPumpSelectedA = false;
    this.isPumpSelectedB = false;

    Object.keys(this.pumpSelection).forEach(key => {
      this.pumpSelection[key] = false;
    });
  }
  onCancelA() {
    Object.keys(this.pumpSelection).forEach(key => {
      this.pumpSelection[key] = false;
    });
    this.isPumpSelectedA = false;
  }
  onCancelB() {
    Object.keys(this.pumpSelection).forEach(key => {
      this.pumpSelection[key] = false;
    });

    this.isPumpSelectedB = false;
  }
}
